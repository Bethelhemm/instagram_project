class AssetsRes {
  static const String = 'assets/.';
}
